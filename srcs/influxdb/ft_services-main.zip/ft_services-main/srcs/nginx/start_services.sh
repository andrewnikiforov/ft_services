#!/bin/sh
#ssh-keygen -A
#telegraf
#nginx -g 'daemon off;'
supervisord -c /etc/supervisord.conf