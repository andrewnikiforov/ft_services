#!/bin/sh
#telegraf
#sh
#cd ../grafana-7.5.5/bin/ && ./grafana-server
supervisord -c /etc/supervisord.conf